public class Partc {
    private int studentID;
    private String name;
    private String department;
    private int marks;

    public Partc() {}
    public Partc(int studentID, String name, String department, int marks) {
        this.studentID = studentID;
        this.name = name;
        this.department = department;
        this.marks = marks;
    }
    public int getStudentID() { return studentID; }
    public void setStudentID(int studentID) { this.studentID = studentID; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }
    public int getMarks() { return marks; }
    public void setMarks(int marks) { this.marks = marks; }
}